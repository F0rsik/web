from django.shortcuts import render

def index(request):
    return render(request, 'astronomy/astronomy.html')

def quiz(request):
    return render(request, 'astronomy/quiz.html')

