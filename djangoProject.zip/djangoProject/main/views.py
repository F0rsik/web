from django.shortcuts import render
from .models import Articles

def index(request):
    news = Articles.objects.order_by('-date')[:4]
    return render(request, 'main/index.html', {'news': news})

def login(request):
    return render(request, 'login/login.html')

def astronomy(request):
    return render(request, 'astronomy/astronomy.html')

