     "use strict";
        window.onload = function() {
            document.getElementById('selectOne').onchange = function (){
                var a = document.getElementById('selectOne').value;
                var text = document.getElementById('mytext');

                switch (a){
                    case'культура и искуство':
                        text.style.color = "Red";
                        break;
                    case 'Blue':
                        text.style.color = "Blue";
                        break;
                    case 'Yellow':
                        text.style.color = "Yellow";
                        break;
                }
                return false;
            }};