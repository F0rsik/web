from django.urls import path
from login.views import LoginUser
from . import views
urlpatterns = [
    path('', views.index),
    path('login/', LoginUser.as_view(), name='login'),
    path('astronomy', views.astronomy, name='astronomy')
]