from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render
from .models import *

#def index(request):
#    return render(request, 'login/login.html')

class LoginUser(LoginView):
    form_class = AuthenticationForm
    template_name = 'login/login.html'