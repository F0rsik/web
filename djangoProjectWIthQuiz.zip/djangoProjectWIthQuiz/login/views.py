from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView

from .models import *

#def index(request):
#    return render(request, 'login/login.html')

class LoginUser(LoginView):
    form_class = AuthenticationForm
    template_name = 'login/login.html'

class RegisterUser(CreateView):
    form_class = UserCreationForm
    template_name = 'login/register.html'
    success_url = reverse_lazy('login')