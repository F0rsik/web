from django.urls import path
from login.views import LoginUser
from login.views import RegisterUser
from . import views
urlpatterns = [
    path('', views.index),
    path('login/', LoginUser.as_view(), name='login'),
    path('register/', RegisterUser.as_view(), name='register'),
    path('astronomy', views.astronomy, name='astronomy')
]