from django.shortcuts import render

def astronomy(request):
    return render(request, 'astronomy/astronomy.html')
