from django.contrib import admin
from django.utils.safestring import mark_safe
from .models import Quiz, Question, Answer, Marks_Of_User, News

class AnswerInLine(admin.TabularInline):
    model = Answer
    
class QuestionAdmin(admin.ModelAdmin):
    inlines = [AnswerInLine]

class NewsAdmin(admin.ModelAdmin):
    readonly_fields = ["preview"]

    def preview(self, obj):
        return mark_safe(f'<img src="{obj.photo.url}">')
    
admin.site.register(Quiz)
admin.site.register(Question, QuestionAdmin)
admin.site.register(Answer)
admin.site.register(News, NewsAdmin)
admin.site.register(Marks_Of_User)