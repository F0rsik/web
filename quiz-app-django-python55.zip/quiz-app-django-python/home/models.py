from django.db import models
from django.contrib.auth.models import User
import random

class Quiz(models.Model):
    name = models.CharField('Название', max_length=50)
    desc = models.CharField('Описание', max_length=500)
    number_of_questions = models.IntegerField('Количество вопросов', default=1)
    time = models.IntegerField('Время на выполнения', help_text="Продолжительность викторины в секундах", default="1")
    
    def __str__(self):
        return self.name

    def get_questions(self):
        return self.question_set.all()
    class Meta:
        verbose_name = 'Викторина(пока такой перевод)'
        verbose_name_plural = 'Викторина'
    
class Question(models.Model):
    content = models.CharField('Вопрос', max_length=200)
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.content
    
    def get_answers(self):
        return self.answer_set.all()
    class Meta:
        verbose_name = 'Вопрос'
        verbose_name_plural = 'Вопросы'
    
    
class Answer(models.Model):
    content = models.CharField(max_length=200)
    correct = models.BooleanField(default=False)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    
    def __str__(self):
        return f"Вопрос: {self.question.content}, Ответ: {self.content}, Верный: {self.correct}"
    class Meta:
        verbose_name = 'Ответ'
        verbose_name_plural = 'Ответы'
    
class Marks_Of_User(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    score = models.FloatField('Баллы')
    
    def __str__(self):
        return str(self.quiz)
    class Meta:
        verbose_name = 'Оценки пользователя'
        verbose_name_plural = 'Оценки пользователей'

class News(models.Model):
    title = models.CharField('Название', max_length=50)
    full_text = models.TextField('Статья')
    min_text = models.TextField('Описание')
    date = models.DateTimeField('Дата публикации')
    photo = models.ImageField('Фото', upload_to='photo', blank=True)


    @property
    def photo_url(self):
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url

    def __str__(self):
        return self.title
    class Meta:
        verbose_name = 'Новость'
        verbose_name_plural = 'Новости'